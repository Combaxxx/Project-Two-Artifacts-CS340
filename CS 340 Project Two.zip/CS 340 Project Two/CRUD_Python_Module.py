from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username='aacuser', password=None):
        # Connection Variables
        USER = username
        PASS = password if password is not None else 'MButler'
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient(
            'mongodb://%s:%s@%s:%d/?authSource=admin'
            % (USER, PASS, HOST, PORT)
        )

        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create method to implement the C in CRUD.
    def create(self, data):
        try:
            if data is not None:
                self.collection.insert_one(data)
                return True
            else:
                return False
        except Exception as e:
            print("An error occurred while inserting data:", e)
            return False

    # Read method to implement the R in CRUD.
    def read(self, query):
        try:
            if query is not None:
                results = self.collection.find(query)
                return list(results)
            else:
                return []
        except Exception as e:
            print("An error occurred while reading data:", e)
            return []

    # Update method to implement the U in CRUD.
    def update(self, query, new_data):
        try:
            if query is not None and new_data is not None:
                result = self.collection.update_many(
                    query,
                    {"$set": new_data}
                )
                return result.modified_count
            else:
                return 0
        except Exception as e:
            print("An error occurred while updating data:", e)
            return 0

    # Delete method to implement the D in CRUD.
    def delete(self, query):
        try:
            if query is not None:
                result = self.collection.delete_many(query)
                return result.deleted_count
            else:
                return 0
        except Exception as e:
            print("An error occurred while deleting data:", e)
            return 0